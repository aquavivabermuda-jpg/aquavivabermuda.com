// Reads the Airbnb calendar (iCal) and returns only the booked date ranges.
// Guest names, reservation codes and phone digits in the Airbnb feed are never sent to the browser.
export default async () => {
  const url = Netlify.env.get("AIRBNB_ICAL_URL");
  if (!url) return Response.json({ error: "not-configured" }, { status: 503 });
  try {
    const res = await fetch(url, { headers: { "User-Agent": "AquaVivaBermuda/1.0" } });
    if (!res.ok) throw new Error("Airbnb returned " + res.status);
    const text = (await res.text()).replace(/\r?\n[ \t]/g, ""); // unfold long lines
    const booked = [];
    for (const block of text.split("BEGIN:VEVENT").slice(1)) {
      const s = block.match(/DTSTART[^:\n]*:(\d{8})/);
      const e = block.match(/DTEND[^:\n]*:(\d{8})/);
      if (!s || !e) continue;
      const iso = (d) => `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`;
      booked.push({ start: iso(s[1]), end: iso(e[1]) }); // end = check-out day (not a booked night)
    }
    booked.sort((a, b) => a.start.localeCompare(b.start));
    return Response.json(
      { updated: new Date().toISOString(), booked },
      { headers: { "Cache-Control": "public, max-age=900" } }
    );
  } catch (err) {
    return Response.json({ error: "fetch-failed" }, { status: 502 });
  }
};

export const config = { path: "/api/availability" };
